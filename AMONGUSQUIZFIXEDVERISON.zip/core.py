print("among us quiz!!!!!!!")
print("also type in all lowercase lol")
print("------------")
player = input("are u sus enough????: ")

if player != "yes":
    print("weak")
    quit()

else:
    print("Good luck >:)))))))")
print("------------")
player = input("True or False; the imposter is sus?: ")

if player != "true":
    print("NOOOO!!!! IMPOSTER IS ALWAYS SUS!!! >:(")
    print("--")

else:
    print("CORRECT!!!! XDD JAJA")
print("------------")
player = input("Who is the imposter (color)???????: ")

if player != "red":
    print("WRONG!!! RED IS THE SUSSY IMPOSTER!!!!! >:((((")


else:
    print("CORRECT!!!! XDD JAJA")
print("------------")

player = input("You have finshed da quiz, type 'quit' to quit now: ")

if player == "quit":
    quit()
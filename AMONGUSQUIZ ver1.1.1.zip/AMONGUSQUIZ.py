import time

print("among us quiz!!!!!!!")
print(" INFOMATION")
print(" Answer in all lowercase.")
print(" If a question is incorrect the program will crash")
print("Now, have fun :)")
print("------------")
print("INTRO QUESTION: ")
time.sleep(0.5)
player = input("are u sus enough???? (Y/N): ")

if player != "y":
    print("weak")
    time.sleep(1)
    quit()

else:
    print("Good luck >:)))))))")
print("------------")
print("Question #1/2: ")
time.sleep(0.3)
player = input("true or false; the imposter is sus?: ")

if player != "true":
    print("NOOOO!!!! IMPOSTER IS ALWAYS SUS!!! >:(")
    time.sleep(1)
    quit()

else:
    print("CORRECT!!!! XDD JAJA")
print("------------")
time.sleep(0.1)
print("Question #2/2: ")
time.sleep(0.3)
player = input("Who is the imposter (color)???????: ")

if player != "red":
    print("WRONG!!! RED IS THE SUSSY IMPOSTER!!!!! >:((((")
    time.sleep(1)
    quit()


else:
    print("CORRECT!!!! XDD JAJA")
print("------------")
time.sleep(0.3)

player = input("You have finshed da quiz, type 'quit' to quit now: ")

if player == "quit":
    print("quiting...")
    time.sleep(1)
    quit()
